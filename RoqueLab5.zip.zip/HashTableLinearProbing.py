# Implementation of hash tables with linear probing
# Programmed by Olac Fuentes
# Last modified October 10, 2019

import numpy as np

class WordEmbed(object): #IMPORT ERROR
    def __init__(self, word, embedding):
        # word must be a string, embedding can be a list or and array of ints or floats
        self.word = word
        self.emb = np.array(embedding, dtype=np.float32)


class HashTableLP(object):
    # Builds a hash table of size 'size', initilizes items to -1 (which means empty)
    # Constructor
    def __init__(self,size):  
        self.item = np.zeros(size,dtype=np.int)-1
        
    def insert(self,k,choice):
        # Inserts k in table unless table is full
        # Returns the position of k in self, or -1 if k could not be inserted
        start = self.h(k.word, choice)
        for i in range(len(self.item)):
            pos = (start + i) % len(self.item)
            if isinstance(self.item[pos], WordEmbed):
                if self.item[pos].word == k.word:
                    return -1
            elif self.item[pos] <= -1:
                self.item[pos] = k
                return pos
    
    
    def find(self,k,choice):
        # Returns the position of k in table, or -1 if k is not in the table
        for i in range(len(self.item)):
            pos = self.h(k+i,choice)
            if self.item[pos] == k:
                return pos
            if self.item[pos] == -1:
                return -1
        return -1
     
    def delete(self,k,choice):
        # Deletes k from table. It returns the position where k was, or -1 if k was not in the table
        # Sets table item where k was to -2 (which means deleted)
        f = self.find(k,choice)
        if f >=0:
            self.item[f] = -2
        return f
    
    def h(self,k,choice):
        if choice == 1:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return len(k) % len(self.item)
        if choice == 2:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return ord(k[0]) % len(self.item)
        if choice == 3:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return (ord(k[0]) * ord(k[-1])) % len(self.item)   
        if choice == 4:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return sum(map(ord, k)) % len(self.item)
        if choice == 5:
           return self.recursive_hash_LP(k)
        if choice == 6:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return ord(k[-1]) % len(self.item)
            
    def recursive_hash_LP(self, k):
        if isinstance(k, WordEmbed):
            k = k.word
        if len(k) == 0:
            return 1
        return (ord(k[0]) + 255 * self.recursive_hash_LP(k[1:])) % len(self.item)

    def print_table(self):
        print('Table contents:')
        print(self.item)
            