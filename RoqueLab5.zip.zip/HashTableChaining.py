# Implementation of hash tables with chaining
# Programmed by Olac Fuentes
# Last modified October 9, 2019
from main import WordEmbed
class HashTableChain(object):
    # Builds a hash table of size 'size'
    # Item is a list of (initially empty) lists
    # Constructor
    def __init__(self,size):  
        self.bucket = [[] for i in range(size)]
    
    #Modified for lab5
    
    
    def h(self,k,choice):
        if choice == 1:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return len(k) % len(self.bucket)
        if choice == 2:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):    
                return ord(k[0]) % len(self.bucket)
        if choice == 3:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):
                return (ord(k[0]) * ord(k[-1])) % len(self.bucket)
        if choice == 4:
            if isinstance(k, WordEmbed):
                k = k.word
            if isinstance(k,str):    
                return sum(map(ord, k)) % len(self.bucket)
        if choice == 5:
           return self.recursive_hash_C(k)
        if choice == 6:
            if isinstance(k, WordEmbed):
                k = k.word
            return ord(k[-1]) % len(self.bucket)
            
    def recursive_hash_C(self, k):
        if isinstance(k, WordEmbed):
            k = k.word
        if len(k) == 0:
            return 1
        return (ord(k[0]) + 255 * self.recursive_hash_C(k[1:])) % len(self.bucket)

    def insert(self,k,choice):
        # Inserts k in appropriate bucket (list) 
        # Does nothing if k is already in the table
        
        b = self.h(k,choice)
        if b is None:
            return
        if not k in self.bucket[b]:
            self.bucket[b].append(k)         #Insert new item at the end
            
    def find(self,k,choice):
        # Returns bucket (b) and index (i) 
        # If k is not in table, i == -1
        b = self.h(k,choice)
        try:
            i = self.bucket[b].index(k)
        except:
            i = -1
        return b, i

    def findEmbeded(self, k, choice):
        b = self.h(k, choice)
        for n in self.bucket[b]:
            if n.word == k:
                return n.emb
        return 
     
    def print_table(self):
        print('Table contents:')
        for b in self.bucket:
            print(b)
    ''' 
    def delete(self,k):
        # Returns k from appropriate list
        # Does nothing if k is not in the table
        # Returns 1 in case of a successful deletion, -1 otherwise
        b = self.h(k,choice)
        try:
            self.bucket[b].remove(k)
            return 1
        except:
            return -1
    '''
    
'''
def main():
    h = HashTableChain(7)
    A = [12,3, 21, 14, 11, 8, 9, 7, 6, 1, 22, 19, 35]
    for a in A:
        h.insert(a)
    h.print_table()
    print(h.find(19))
    print(h.find(15))
    h.delete(14)
    h.delete(19)
    h.print_table()
    
if __name__ == "__main__":    
    main()
    '''
    
    
    